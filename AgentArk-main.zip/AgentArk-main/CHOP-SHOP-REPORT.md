# AgentArk — local Chop Shop overhaul

Source archive SHA-256:
`1503a185c04d363581dc89fb242a42dc249bd9c24ed2cd86eb66ca1aaec834e2`.

Completed changes:
- Lazy method selection, deterministic aliases and isolated DyLAN imports.
- Shared API compatibility for conversations/system prompts, bearer authentication,
  explicit zero temperature, bounded retries and propagated transport failures.
- Optional API config for local inference; module-relative method YAML; respected
  LLM Debate agent count and tensor-parallel setting.
- Inference input validation/dry-run, consistent slicing/resume, initialization
  error records and checked batch outputs.
- UTF-8 JSONL helpers, preservation of failed rows for retry, interrupted-tail
  detection, locked appends and atomic complete-file output.
- Labeling that preserves short prompts, counts the actual chat token IDs and
  generation reserve, honors GPU/token options and rejects invalid labels.
- ToRA-derived boxed-answer parsing; finite-scalar numeric grading; repaired
  evaluation imports and safe Windows/POSIX metrics-directory parsing.
- Offline saved-result exact/numeric/token-F1 evaluation, corrected Quick Start,
  sample inputs/API config, separate dependency lists and CI.

Validation: 52 offline regression tests passed on local Python 3.13, including
all 191 Python sources compiling. All 191 also parse with Python 3.10 grammar.
Four CLI help paths passed with site packages disabled. The two synthetic numeric
examples scored 2/2; this is a fixture check, not a model benchmark.
Windows restricted-token tests used the Chop Shop's temporary-directory
compatibility host; test assertions were unchanged. Plain runs first failed
because Python-created owner-only temporary folders were inaccessible to the
restricted token. Existing invalid-escape SyntaxWarnings remain in vendor/research code.

Not validated: actual GPU inference, full symbolic/ROUGE/BERTScore evaluation,
distributed PRM/GRPO training, external datasets, Modal service, and the absent
legacy xverify dependency. CI jobs are configured but have not run remotely.
No model-quality improvement is claimed. Original GPU pins and training
algorithms remain; see OPERATIONS.md for remaining method-specific assumptions.

Donor provenance and full MIT text: THIRD-PARTY-NOTICES.md. The yard work order
and external archive manifest record preservation and installation checks.
