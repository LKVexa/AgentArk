"""Shared local/API backend with compatible prompt and conversation calls."""
import asyncio
import inspect
import random
import time
from pathlib import Path
from urllib.parse import urlparse


class MAS:
    def __init__(self, general_config, method_config_name=None, tensor_parallel_size=None):
        if method_config_name is not None:
            from methods.utils import load_config
            module_dir = Path(inspect.getfile(type(self))).resolve().parent
            self.method_config = load_config(module_dir / "configs" / f"{method_config_name}.yaml")
        self.model_api_config = general_config.get("model_api_config", {})
        self.model_name = general_config["model_name"]
        self.model_temperature = general_config["model_temperature"]
        self.model_max_tokens = general_config["model_max_tokens"]
        self.model_timeout = general_config["model_timeout"]
        self.tensor_parallel_size = (tensor_parallel_size if tensor_parallel_size is not None
                                     else general_config.get("tensor_parallel_size", 1))
        self.model_retries = general_config.get("model_retries", 5)
        self.retry_delay = general_config.get("model_retry_delay", 4)
        if self.model_retries < 1 or self.retry_delay < 0:
            raise ValueError("model_retries must be positive and retry delay nonnegative")
        self.gpu_memory_utilization = 0.9
        self.token_stats = {self.model_name: {"num_llm_calls": 0, "prompt_tokens": 0, "completion_tokens": 0}}
        self.memory_bank = {}
        self.tools = {}

    def inference(self, sample):
        return {"response": self.call_llm(prompt=sample["query"])}

    def inference_batch(self, samples, dataset_name=None):
        from vllm import LLM, SamplingParams
        from transformers import AutoTokenizer
        if not samples:
            return []
        if not hasattr(self, "_vllm_engine"):
            self._vllm_engine = LLM(model=self.model_name,
                                    tensor_parallel_size=self.tensor_parallel_size,
                                    trust_remote_code=True,
                                    gpu_memory_utilization=self.gpu_memory_utilization)
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        prompts = [self.tokenizer.apply_chat_template(
            [{"role": "user", "content": sample["query"]}],
            tokenize=False, add_generation_prompt=True) for sample in samples]
        outputs = self._vllm_engine.generate(prompts, SamplingParams(
            temperature=self.model_temperature, max_tokens=self.model_max_tokens,
            stop=["</s>", "<|im_end|>", "<|endoftext|>"]))
        outputs = sorted(outputs, key=lambda output: int(output.request_id))
        if len(outputs) != len(samples):
            raise ValueError("vLLM output/sample count mismatch")
        for output in outputs:
            self._record_usage(self.model_name, {
                "prompt_tokens": len(output.prompt_token_ids),
                "completion_tokens": len(output.outputs[0].token_ids)})
        return [{"response": output.outputs[0].text} for output in outputs]

    def _request(self, prompt, system_prompt, messages, model_name, temperature, extra_body):
        key = model_name or self.model_name
        try:
            model = random.choice(self.model_api_config[key]["model_list"])
        except (KeyError, IndexError) as error:
            raise ValueError(f"No API configuration for model {key!r}") from error
        url = model["model_url"].rstrip("/")
        if messages is None:
            if prompt is None:
                raise ValueError("Provide prompt or messages")
            messages = ([{"role": "system", "content": system_prompt}] if system_prompt else [])
            messages += [{"role": "user", "content": prompt}]
        elif system_prompt:
            messages = [{"role": "system", "content": system_prompt}, *messages]
        chat = "/chat/completions" in urlparse(url).path
        payload = {
            "model": model["model_name"],
            "max_tokens": self.model_max_tokens,
            "temperature": self.model_temperature if temperature is None else temperature,
        }
        if chat:
            payload["messages"] = messages
        else:
            payload["prompt"] = (prompt if prompt is not None and not system_prompt else
                                 "\n".join(f"{m['role']}: {m['content']}" for m in messages))
        if extra_body:
            payload.update(extra_body)
        headers = {"Content-Type": "application/json"}
        if model.get("api_key"):
            headers["Authorization"] = "Bearer " + model["api_key"]
        return key, url, headers, payload, chat

    def _record_usage(self, model, usage):
        stats = self.token_stats.setdefault(model, {"num_llm_calls": 0, "prompt_tokens": 0, "completion_tokens": 0})
        stats["num_llm_calls"] += 1
        stats["prompt_tokens"] += usage.get("prompt_tokens", 0)
        stats["completion_tokens"] += usage.get("completion_tokens", 0)

    def _response(self, key, result, chat):
        choice = result["choices"][0]
        text = choice["message"]["content"] if chat else choice["text"]
        if not isinstance(text, str) or not text.strip():
            raise ValueError("Model returned an empty/non-text response")
        self._record_usage(key, result.get("usage") or {})
        return text.strip()

    def call_llm(self, prompt=None, system_prompt=None, messages=None,
                 model_name=None, temperature=None, extra_body=None):
        import requests
        key, url, headers, payload, chat = self._request(
            prompt, system_prompt, messages, model_name, temperature, extra_body)
        for attempt in range(self.model_retries):
            try:
                with requests.post(url, headers=headers, json=payload,
                                   timeout=self.model_timeout) as response:
                    response.raise_for_status()
                    return self._response(key, response.json(), chat)
            except requests.RequestException:
                if attempt + 1 == self.model_retries:
                    raise
                time.sleep(min(self.retry_delay * 2 ** attempt, 10))

    async def call_llm_async(self, prompt=None, model_name=None, temperature=None,
                             extra_body=None, system_prompt=None, messages=None):
        import aiohttp
        key, url, headers, payload, chat = self._request(
            prompt, system_prompt, messages, model_name, temperature, extra_body)
        async with aiohttp.ClientSession() as session:
            for attempt in range(self.model_retries):
                try:
                    async with session.post(url, headers=headers, json=payload,
                                            timeout=aiohttp.ClientTimeout(total=self.model_timeout)) as response:
                        response.raise_for_status()
                        return self._response(key, await response.json(), chat)
                except (aiohttp.ClientError, asyncio.TimeoutError):
                    if attempt + 1 == self.model_retries:
                        raise
                    await asyncio.sleep(min(self.retry_delay * 2 ** attempt, 10))

    def get_token_stats(self):
        return self.token_stats

    def optimizing(self, val_data):
        pass

    def retrieve_memory(self):
        pass

    def update_memory(self):
        pass

    def get_tool(self):
        pass
