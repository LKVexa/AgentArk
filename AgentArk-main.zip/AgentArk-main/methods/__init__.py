"""Lazy method registry: importing CLI utilities never loads GPU backends."""
from collections.abc import Mapping
from importlib import import_module
import re

_METHODS = {
    "vanilla": ("mas_base.mas_base", "MAS"),
    "cot": ("cot.cot_main", "CoT"),
    "agentverse_humaneval": ("agentverse.agentverse_humaneval", "AgentVerse_HumanEval"),
    "agentverse_mgsm": ("agentverse.agentverse_mgsm", "AgentVerse_MGSM"),
    "agentverse": ("agentverse.agentverse_main", "AgentVerse_Main"),
    "llm_debate": ("llm_debate.llm_debate_main", "LLM_Debate_Main"),
    "dylan_humaneval": ("dylan.dylan_humaneval", "DyLAN_HumanEval"),
    "dylan_math": ("dylan.dylan_math", "DyLAN_MATH"),
    "dylan_mmlu": ("dylan.dylan_mmlu", "DyLAN_MMLU"),
    "dylan": ("dylan.dylan_main", "DyLAN_Main"),
    "autogen": ("autogen.autogen_main", "AutoGen_Main"),
    "camel": ("camel.camel_main", "CAMEL_Main"),
    "evomac": ("evomac.evomac_main", "EvoMAC_Main"),
    "chatdev_srdd": ("chatdev.chatdev_srdd", "ChatDev_SRDD"),
    "macnet": ("macnet.macnet_main", "MacNet_Main"),
    "macnet_srdd": ("macnet.macnet_srdd", "MacNet_SRDD"),
    "mad": ("mad.mad_main", "MAD_Main"),
    "mapcoder_humaneval": ("mapcoder.mapcoder_humaneval", "MapCoder_HumanEval"),
    "mapcoder_mbpp": ("mapcoder.mapcoder_mbpp", "MapCoder_MBPP"),
    "self_consistency": ("self_consistency.self_consistency_main", "SelfConsistency"),
    "mav_gpqa": ("mav.mav_gpqa", "MAV_GPQA"),
    "mav_humaneval": ("mav.mav_humaneval", "MAV_HumanEval"),
    "mav_main": ("mav.mav_main", "MAV_Main"),
    "mav_math": ("mav.mav_math", "MAV_MATH"),
    "mav_mmlu": ("mav.mav_mmlu", "MAV_MMLU"),
}
_ALIASES = {"mav": "mav_main", "chatdev": "chatdev_srdd", "mas_base": "vanilla"}
__all__ = ["get_method_class", "resolve_method_name", "method2class",
           *[symbol for _, symbol in _METHODS.values()]]


def resolve_method_name(method_name, dataset_name=None):
    name = method_name.lower()
    if name not in _METHODS and name not in _ALIASES and name != "mapcoder":
        raise ValueError(f"Unknown method {method_name!r}; choose from {', '.join(sorted(_METHODS | _ALIASES))}")
    dataset = re.sub(r"[^a-z0-9]", "", (dataset_name or "").lower())
    if name in {"agentverse", "dylan", "mav", "macnet", "mapcoder"}:
        matches = [key for key in _METHODS if key.startswith(name + "_")
                   and key.rsplit("_", 1)[1] != "main"
                   and key.rsplit("_", 1)[1] in dataset]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise ValueError(f"Ambiguous dataset {dataset_name!r}; choose an explicit method: {matches}")
    name = _ALIASES.get(name, name)
    if name not in _METHODS:
        raise ValueError("mapcoder requires HumanEval or MBPP, or an explicit mapcoder_* method")
    return name


class _MethodRegistry(Mapping):
    def __iter__(self):
        return iter(_METHODS)

    def __len__(self):
        return len(_METHODS)

    def __getitem__(self, name):
        module, symbol = _METHODS[name]
        return getattr(import_module("." + module, __name__), symbol)


method2class = _MethodRegistry()


def get_method_class(method_name, dataset_name=None):
    return method2class[resolve_method_name(method_name, dataset_name)]


def __getattr__(symbol):
    for name, (_, exported) in _METHODS.items():
        if exported == symbol:
            value = method2class[name]
            globals()[symbol] = value
            return value
    raise AttributeError(symbol)
