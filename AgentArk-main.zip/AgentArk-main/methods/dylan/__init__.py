from importlib import import_module

_EXPORTS = {"DyLAN_Main": "dylan_main", "DyLAN_MMLU": "dylan_mmlu",
            "DyLAN_HumanEval": "dylan_humaneval", "DyLAN_MATH": "dylan_math"}

def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError(name)
    return getattr(import_module("." + _EXPORTS[name], __name__), name)
