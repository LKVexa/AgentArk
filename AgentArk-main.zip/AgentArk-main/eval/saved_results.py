"""Score existing inference JSONL without loading a model or executing response text."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import string
from utils import load_jsonl, save_jsonl
from utils.numeric import compare_answers


def exact_match(prediction, reference):
    return float(" ".join(prediction.casefold().split()) == " ".join(reference.casefold().split()))


def token_f1(prediction, reference):
    def tokens(text):
        text = text.casefold().translate(str.maketrans("", "", string.punctuation))
        return re.sub(r"\b(a|an|the)\b", " ", text).split()
    predicted, expected = tokens(prediction), tokens(reference)
    if not predicted or not expected:
        return float(predicted == expected)
    overlap = sum((Counter(predicted) & Counter(expected)).values())
    return 2 * overlap / (len(predicted) + len(expected))


def evaluate_rows(rows, metric="exact"):
    scorer = {"exact": exact_match, "token-f1": token_f1, "numeric": compare_answers}[metric]
    total = failed = 0
    score = 0.0
    for index, row in enumerate(rows):
        reference = row.get("gt", row.get("ground_truth"))
        if reference is None:
            raise ValueError(f"Record {index} has no gt/ground_truth")
        references = reference if isinstance(reference, list) else [reference]
        if not references or any(value is None for value in references):
            raise ValueError(f"Record {index} has no usable reference")
        prediction = row.get("answer_extracted", row.get("response"))
        total += 1
        if row.get("error") or not isinstance(prediction, str) or not prediction.strip():
            failed += 1
            continue
        score += max(float(scorer(prediction, str(value))) for value in references)
    return {"metric": metric, "total": total, "valid": total - failed, "failed": failed,
            "mean_score": score / total if total else 0.0,
            "score_percent": score / total * 100 if total else 0.0}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input_file", required=True)
    parser.add_argument("--metric", choices=["exact", "numeric", "token-f1"], default="exact")
    parser.add_argument("--dataset_name", help="Informational label; does not select another grading protocol")
    parser.add_argument("--output", help="Optional one-record JSONL summary")
    args = parser.parse_args(argv)
    if args.output and Path(args.output).resolve() == Path(args.input_file).resolve():
        parser.error("Input and output must differ")
    report = evaluate_rows(load_jsonl(args.input_file), args.metric)
    if args.dataset_name:
        report["dataset_name"] = args.dataset_name
    if args.output:
        save_jsonl([report], args.output)
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
