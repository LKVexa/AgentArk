"""
Calculate metrics for GSM8K dataset predictions.
This script extracts answers from \boxed{} if needed, and calculates accuracy.
"""
import json
import os
import re
from typing import List, Dict, Any
from pathlib import Path
if __package__ in (None, ""):
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from utils import load_jsonl
from utils.numeric import extract_boxed_answer, normalize_answer, compare_answers




def process_predictions(input_file: str, output_file: str = None):
    """
    Process predictions from GSM8K file.
    - Extracts answers from \boxed{} if answer_extracted field doesn't exist
    - Calculates accuracy metrics
    - Saves results
    """
    print(f"Loading predictions from: {input_file}")
    import pandas as pd

    predictions = list(load_jsonl(input_file))

    print(f"Loaded {len(predictions)} predictions")

    # Process each prediction
    results = []
    correct_count = 0
    total_count = 0

    for item in predictions:
        idx = item.get('idx', None)
        question = item.get('question', item.get('query', ''))
        ground_truth = item.get('ground_truth', item.get('gt'))
        if ground_truth is None:
            raise ValueError("Prediction is missing ground_truth/gt")

        # Extract answer from \boxed{} in code field
        code = item.get('code', [])
        response = item.get('response', code[0] if isinstance(code, list) and code else '')
        pred_answer = item.get('answer_extracted', extract_boxed_answer(response) or response)

        # Compare answers
        is_correct = not item.get('error') and compare_answers(pred_answer, ground_truth)

        if is_correct:
            correct_count += 1
        total_count += 1

        # Store result
        results.append({
            'idx': idx,
            'question': question,
            'ground_truth': ground_truth,
            'prediction': pred_answer,
            'correct': is_correct
        })

    # Calculate metrics
    accuracy = (correct_count / total_count * 100) if total_count > 0 else 0.0
    
    incorrect_answers = [result for result in results if not result['correct']]

    print(f"\n{'='*60}")
    print(f"Results:")
    print(f"{'='*60}")
    print(f"Total samples: {total_count}")
    print(f"Correct: {correct_count}")
    print(f"Incorrect: {total_count - correct_count}")
    print(f"Accuracy: {accuracy:.2f}%")
    print(f"{'='*60}\n")

    # Save results to Excel
    if output_file is None:
        output_file = str(Path(input_file).with_name(Path(input_file).stem + '_metrics.xlsx'))
    if Path(output_file).resolve() == Path(input_file).resolve():
        raise ValueError("Input and output must differ")

    df = pd.DataFrame(results)
    df.to_excel(output_file, index=False)
    print(f"Detailed results saved to: {output_file}")

    # Also save summary
    summary_file = str(Path(output_file).with_name(Path(output_file).stem + '_summary.txt'))
    with open(summary_file, 'w') as f:
        f.write(f"GSM8K Evaluation Results\n")
        f.write(f"{'='*60}\n")
        f.write(f"Input file: {input_file}\n")
        f.write(f"Total samples: {total_count}\n")
        f.write(f"Correct: {correct_count}\n")
        f.write(f"Incorrect: {total_count - correct_count}\n")
        f.write(f"Accuracy: {accuracy:.2f}%\n")
        f.write(f"{'='*60}\n")

    print(f"Summary saved to: {summary_file}")

    return {
        'total': total_count,
        'correct': correct_count,
        'incorrect': total_count - correct_count,
        'accuracy': accuracy
    }


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python calculate_metrics_numeric.py <input_jsonl_file> [output_xlsx_file]")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None

    if not os.path.exists(input_file):
        print(f"Error: Input file not found: {input_file}")
        sys.exit(1)

    process_predictions(input_file, output_file)
