"""AgentArk evaluation entry points. Prefer python -m eval.<command>."""
