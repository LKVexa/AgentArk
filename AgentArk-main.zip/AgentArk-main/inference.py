"""Run multi-agent inference over local JSON/JSONL data."""
import argparse
import asyncio
import inspect
import json
import threading
import time
import traceback
from pathlib import Path
from methods import get_method_class, resolve_method_name
from utils import load_jsonl, load_model_api_config, reserve_unprocessed_queries, write_to_jsonl


def create_method(args, general_config, *, batch=False):
    cls = get_method_class(args.method_name, args.test_dataset_name)
    kwargs = {"method_config_name": args.method_config_name}
    if "tensor_parallel_size" in inspect.signature(cls).parameters:
        kwargs["tensor_parallel_size"] = args.tensor_parallel_size
    if batch and args.use_vllm:
        from methods.mas_base import MAS
        if cls is not MAS and "inference_batch" not in cls.__dict__:
            raise ValueError(f"{args.method_name} has no method-specific vLLM batch implementation; use the API backend")
    return cls(general_config, **kwargs)


def validate_outputs(samples, outputs):
    if not isinstance(outputs, (list, tuple)) or len(outputs) != len(samples):
        raise ValueError("Batch output/sample count mismatch; no rows from this batch were saved")
    for index, output in enumerate(outputs):
        if (not isinstance(output, dict) or not isinstance(output.get("response"), str)
                or not output["response"].strip() or output.get("error")):
            raise ValueError(f"Invalid or failed response for batch item {index}")


def process_sample(args, general_config, sample, output_path, lock, dataset_name=None):
    save_data = sample.copy()
    mas = None
    try:
        mas = create_method(args, general_config)
        output = mas.inference(sample)
        validate_outputs([sample], [output])
        save_data.update(output)
        save_data["token_stats"] = mas.get_token_stats()
        save_data.pop("error", None)
    except Exception:
        save_data["error"] = f"Inference Error: {traceback.format_exc()}"
    write_to_jsonl(lock, output_path, save_data)
    return not bool(save_data.get("error"))


def load_samples(path):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Dataset not found: {path}. Supply --input_file with JSON/JSONL rows containing query.")
    if path.suffix.lower() == ".jsonl":
        samples = list(load_jsonl(path))
    else:
        with path.open(encoding="utf-8-sig") as source:
            samples = json.load(source)
    if not isinstance(samples, list):
        raise ValueError("Input must be a JSON array or JSONL objects")
    for index, sample in enumerate(samples):
        if not isinstance(sample, dict) or not isinstance(sample.get("query"), str) or not sample["query"].strip():
            raise ValueError(f"Input item {index} needs a nonempty string query")
    return samples


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--method_name", default="vanilla")
    parser.add_argument("--method_config_name", default=None)
    parser.add_argument("--model_name", default="Qwen/Qwen3-32B")
    parser.add_argument("--model_api_config", default="model_api_configs/model_api_config.json")
    parser.add_argument("--model_temperature", type=float, default=0.5)
    parser.add_argument("--model_max_tokens", type=int, default=4096)
    parser.add_argument("--model_timeout", type=int, default=600)
    parser.add_argument("--test_dataset_name", default="MATH")
    parser.add_argument("--input_file", help="Local JSON array or JSONL with query fields")
    parser.add_argument("--validation_file", help="Local validation data when --require_val is set")
    parser.add_argument("--output_path")
    parser.add_argument("--result_dir", default="results")
    parser.add_argument("--require_val", action="store_true")
    parser.add_argument("--max-samples", type=int)
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--dry-run", action="store_true", help="Validate routing, data and resume state without loading a backend")
    parser.add_argument("--sequential", action="store_true", help="Compatibility flag; API samples run sequentially")
    parser.add_argument("--tensor_parallel_size", type=int, default=1)
    backend = parser.add_mutually_exclusive_group()
    backend.add_argument("--use_vllm", action="store_true")
    backend.add_argument("--use_modal_batch", action="store_true")
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--batch_attempts", type=int, default=3)
    parser.add_argument("--retry_delay", type=float, default=15)
    args = parser.parse_args(argv)
    if args.start < 0 or (args.max_samples is not None and args.max_samples < 0):
        parser.error("--start and --max-samples must be nonnegative")
    if min(args.tensor_parallel_size, args.model_max_tokens, args.model_timeout, args.batch_attempts) < 1:
        parser.error("GPU count, token budget, timeout and batch attempts must be positive")
    if args.retry_delay < 0:
        parser.error("--retry_delay must be nonnegative")
    return args


def main(argv=None):
    args = parse_args(argv)
    resolved = resolve_method_name(args.method_name, args.test_dataset_name)
    samples = ([{"query": "What is 1 + 3?"}] if args.debug else
               load_samples(args.input_file or Path("datasets/data") / f"{args.test_dataset_name}.json"))
    samples = samples[args.start:]
    if args.max_samples is not None:
        samples = samples[:args.max_samples]
    output = Path(args.output_path) if args.output_path else (
        Path(args.result_dir) / args.test_dataset_name / args.model_name / f"{args.method_name}_infer.jsonl")
    if args.input_file and output.resolve() == Path(args.input_file).resolve():
        raise ValueError("Input and output must be different files")
    if not args.debug:
        samples = reserve_unprocessed_queries(output, samples)
    validation = None
    if args.require_val:
        validation = load_samples(args.validation_file or Path("datasets/data") / f"{args.test_dataset_name}_val.json")
    if args.dry_run:
        print(json.dumps({"method": resolved, "pending_samples": len(samples),
                          "output": str(output), "backend_loaded": False}, indent=2))
        return 0
    if not samples:
        print("No pending samples.")
        return 0
    config = vars(args).copy()
    if not args.use_vllm and not args.use_modal_batch:
        config["model_api_config"] = load_model_api_config(args.model_api_config, args.model_name)
        print(f"Loaded API configuration for {args.model_name}")  # Do not print credentials.
    else:
        config["model_api_config"] = {}
    lock = threading.Lock()
    if args.debug:
        mas = create_method(args, config)
        print(json.dumps(mas.inference(samples[0]), indent=2))
        return 0
    if validation is not None:
        create_method(args, config).optimizing(validation)
    output.parent.mkdir(parents=True, exist_ok=True)
    if args.use_vllm or args.use_modal_batch:
        mas = create_method(args, config, batch=True)
        batch_size = 10 if args.use_modal_batch else len(samples)
        if args.use_modal_batch and not callable(getattr(mas, "inference_vllm_batch", None)):
            raise ValueError(f"{args.method_name} does not implement Modal batch inference")
        for start in range(0, len(samples), batch_size):
            batch = samples[start:start + batch_size]
            if args.use_vllm:
                outputs = mas.inference_batch(batch, args.test_dataset_name)
            else:
                for attempt in range(args.batch_attempts):
                    try:
                        outputs = asyncio.run(mas.inference_vllm_batch(batch, args.test_dataset_name))
                        validate_outputs(batch, outputs)
                        break
                    except Exception:
                        if attempt + 1 == args.batch_attempts:
                            raise
                        time.sleep(args.retry_delay)
            validate_outputs(batch, outputs)
            for sample, result in zip(batch, outputs):
                row = {**sample, **result, "token_stats": mas.get_token_stats()}
                row.pop("error", None)
                write_to_jsonl(lock, output, row)
        return 0
    failed = sum(not process_sample(args, config, sample, output, lock) for sample in samples)
    print(f"Saved {len(samples)} records to {output}; failed: {failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
