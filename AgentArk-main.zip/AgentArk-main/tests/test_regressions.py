"""Offline regressions for repository-owned integration behavior.

Model and network transports are explicit fakes. No downloads or GPU required.
"""
import ast
import asyncio
import contextlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import inference
import label
from methods import resolve_method_name
from methods.mas_base import MAS
from utils import load_jsonl, save_jsonl, load_model_api_config, reserve_unprocessed_queries
from utils.jsonl import append_jsonl
from utils.numeric import compare_answers, extract_boxed_answer, extract_final_answer
from eval.saved_results import evaluate_rows
from eval.calculate_metrics_short_answer import parse_max_length

ROOT = Path(__file__).resolve().parents[1]


class WorkspaceTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.path = self.directory / "records.jsonl"


class JsonlTests(WorkspaceTest):
    def test_unicode_blank_lines_and_bom(self):
        self.path.write_text('\ufeff{"query":"雪"}\n\n', encoding="utf-8")
        self.assertEqual(list(load_jsonl(self.path)), [{"query": "雪"}])

    def test_malformed_line_reports_location(self):
        self.path.write_text('{}\n{"query":\n', encoding="utf-8")
        with self.assertRaisesRegex(ValueError, r":2: invalid"):
            list(load_jsonl(self.path))

    def test_nonobject_is_rejected(self):
        self.path.write_text('[]\n', encoding="utf-8")
        with self.assertRaises(ValueError):
            list(load_jsonl(self.path))

    def test_tolerant_reader_warns(self):
        self.path.write_text('{}\ninvalid\n{}\n', encoding="utf-8")
        with self.assertWarns(RuntimeWarning):
            self.assertEqual(len(list(load_jsonl(self.path, skip_invalid=True))), 2)

    def test_unterminated_valid_row_gets_separator(self):
        self.path.write_text('{"query":"first"}', encoding="utf-8")
        append_jsonl(self.path, [{"query": "second"}])
        self.assertEqual(len(list(load_jsonl(self.path))), 2)

    def test_partial_tail_is_preserved_and_rejected(self):
        original = b'{"query":"unfinished'
        self.path.write_bytes(original)
        with self.assertRaisesRegex(ValueError, "incomplete final"):
            append_jsonl(self.path, [{"query": "new"}])
        self.assertEqual(self.path.read_bytes(), original)

    def test_failed_serialization_preserves_old_output(self):
        save_jsonl([{"old": True}], self.path)
        with self.assertRaises(TypeError):
            save_jsonl([{"new": True}, {"invalid": object()}], self.path)
        self.assertEqual(list(load_jsonl(self.path)), [{"old": True}])
        self.assertEqual(list(self.directory.iterdir()), [self.path])

    def test_locked_writers_keep_complete_records(self):
        lock = threading.Lock()
        threads = [threading.Thread(target=append_jsonl, args=(self.path, [{"index": n}], lock))
                   for n in range(20)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(sorted(row["index"] for row in load_jsonl(self.path)), list(range(20)))

    def test_resume_retries_failures_but_keeps_scored_zero(self):
        rows = [{"query": "ok", "response": "answer"},
                {"query": "error", "error": "failed", "response": "partial"},
                {"query": "null", "response": None},
                {"query": "wrong", "eval_score": 0},
                {"query": "eval-error", "eval_score": None}]
        save_jsonl(rows, self.path)
        queries = [{"query": row["query"]} for row in rows]
        self.assertEqual([row["query"] for row in reserve_unprocessed_queries(self.path, queries)],
                         ["error", "null", "eval-error"])

    def test_environment_api_key(self):
        config = {"m": {"model_list": [{"model_name": "m", "model_url": "http://localhost/v1/chat/completions",
                                      "api_key_env": "ARK_TEST_KEY"}]}}
        self.path.write_text(json.dumps(config), encoding="utf-8")
        with patch.dict(os.environ, {"ARK_TEST_KEY": "test-only"}):
            entry = load_model_api_config(self.path, "m")["m"]
        self.assertEqual(entry["max_workers"], 1)
        self.assertEqual(entry["model_list"][0]["api_key"], "test-only")

    def test_unknown_model_fails_clearly(self):
        self.path.write_text("{}", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "not configured"):
            load_model_api_config(self.path, "missing")


class NumericTests(unittest.TestCase):
    def test_nested_braces_and_final_box(self):
        text = r"First \boxed{8}; finally \boxed{-\frac{1}{2}}."
        self.assertEqual(extract_boxed_answer(text), r"-\frac{1}{2}")

    def test_unclosed_final_box_is_not_a_previous_answer(self):
        self.assertEqual(extract_boxed_answer(r"\boxed{4}, then \boxed{"), "")

    def test_signed_decimal_ground_truth(self):
        self.assertEqual(extract_final_answer("work 2 + 3\n#### -1.25"), "-1.25")

    def test_numeric_equivalences(self):
        pairs = [(r"\boxed{-\frac{1}{2}}", "-0.5"), ("1,000", "1e3"),
                 ("25%", "0.25"), ("-3/4", "-0.75"), ("+0.5", r"\frac{1}{2}")]
        for left, right in pairs:
            with self.subTest(left=left):
                self.assertTrue(compare_answers(left, right))

    def test_invalid_scalars_do_not_match(self):
        for value in ["", "NaN", "inf", "1/0", "x", "1e100000", "__import__('os')"]:
            with self.subTest(value=value):
                self.assertFalse(compare_answers(value, value))

    def test_scores_count_failed_rows(self):
        report = evaluate_rows([{"gt": "4", "response": r"\boxed{4}"},
                                {"gt": "4", "error": "failed"}], "numeric")
        self.assertEqual(report["failed"], 1)
        self.assertEqual(report["mean_score"], 0.5)

    def test_empty_results(self):
        self.assertEqual(evaluate_rows([], "numeric")["mean_score"], 0)

    def test_multiple_references(self):
        report = evaluate_rows([{"gt": ["New York", "NY"], "response": "ny"}])
        self.assertEqual(report["mean_score"], 1)

    def test_token_f1_uses_repeated_token_counts(self):
        report = evaluate_rows([{"gt": "red red blue", "response": "red blue blue"}], "token-f1")
        self.assertAlmostEqual(report["mean_score"], 2 / 3)

    def test_path_parser_supports_both_separators(self):
        self.assertEqual(parse_max_length(r"C:\out\max_length_2048\metrics.csv"), 2048)
        self.assertEqual(parse_max_length("/out/max_length_4096/metrics.csv"), 4096)
        self.assertIsNone(parse_max_length("metrics.csv"))

    def test_path_parser_rejects_expressions(self):
        with self.assertRaises(ValueError):
            parse_max_length("max_length_2+2/metrics.csv")


def config():
    return {"model_name": "m", "model_temperature": 0.7, "model_max_tokens": 30,
            "model_timeout": 10, "model_retries": 3, "model_retry_delay": 0,
            "model_api_config": {"m": {"model_list": [
                {"model_name": "actual", "model_url": "http://localhost/v1/chat/completions",
                 "api_key": "test-only"}]}}}


class MethodTests(unittest.TestCase):
    def test_debate_config_and_tensor_size_without_gpu_import(self):
        loader = Mock(return_value={"agents_num": 3, "rounds_num": 2})
        with patch.dict(sys.modules, {"methods.utils": SimpleNamespace(load_config=loader),
                                     "requests": SimpleNamespace()}):
            from methods.llm_debate.llm_debate_main import LLM_Debate_Main
            method = LLM_Debate_Main(config(), tensor_parallel_size=2)
        self.assertEqual(method.tensor_parallel_size, 2)
        self.assertEqual(method.agents_num, 3)
        self.assertEqual(Path(loader.call_args.args[0]),
                         ROOT / "methods" / "llm_debate" / "configs" / "config_main.yaml")

    def test_dylan_general_variant_has_no_humaneval_dependency(self):
        result = subprocess.run([sys.executable, "-B", "-S", "-c",
                                 "from methods import get_method_class; print(get_method_class('dylan').__name__)"],
                                cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("DyLAN_Main", result.stdout)

    def test_family_routing(self):
        cases = [("mav", "QMSum", "mav_main"), ("mav", "MATH", "mav_math"),
                 ("dylan", "MMLU-Pro", "dylan_mmlu"), ("mapcoder", "MBPP", "mapcoder_mbpp"),
                 ("chatdev", None, "chatdev_srdd"), ("vanilla", "MATH", "vanilla")]
        for method, dataset, expected in cases:
            self.assertEqual(resolve_method_name(method, dataset), expected)

    def test_explicit_variant_is_preserved(self):
        self.assertEqual(resolve_method_name("dylan_math", "MMLU"), "dylan_math")

    def test_substring_method_rejected(self):
        with self.assertRaises(ValueError):
            resolve_method_name("ma", "MATH")

    def test_mapcoder_requires_dataset(self):
        with self.assertRaisesRegex(ValueError, "requires HumanEval or MBPP"):
            resolve_method_name("mapcoder")

    def test_local_config_optional(self):
        settings = config()
        settings.pop("model_api_config")
        self.assertEqual(MAS(settings).model_api_config, {})

    def test_vanilla_is_unconstrained(self):
        method = MAS(config())
        method.call_llm = Mock(return_value="42")
        self.assertEqual(method.inference({"query": "six times seven"})["response"], "42")
        method.call_llm.assert_called_once_with(prompt="six times seven")

    def test_api_messages_authentication_zero_temperature(self):
        method = MAS(config())
        response = Mock()
        response.__enter__ = Mock(return_value=response)
        response.__exit__ = Mock(return_value=False)
        response.json.return_value = {"choices": [{"message": {"content": " 4 "}}],
                                      "usage": {"prompt_tokens": 10, "completion_tokens": 1}}
        transport = SimpleNamespace(post=Mock(return_value=response), RequestException=OSError)
        messages = [{"role": "user", "content": "1+3"}]
        with patch.dict(sys.modules, {"requests": transport}):
            self.assertEqual(method.call_llm(None, None, messages, temperature=0), "4")
        kwargs = transport.post.call_args.kwargs
        self.assertEqual(kwargs["json"]["messages"], messages)
        self.assertEqual(kwargs["json"]["temperature"], 0)
        self.assertEqual(kwargs["headers"]["Authorization"], "Bearer test-only")
        self.assertEqual(method.get_token_stats()["m"]["num_llm_calls"], 1)

    def test_system_prompt_works(self):
        request = MAS(config())._request("question", "system", None, None, 0, None)
        self.assertEqual(request[3]["messages"][0], {"role": "system", "content": "system"})

    def test_retry_exhaustion_raises_after_exact_limit(self):
        transport = SimpleNamespace(post=Mock(side_effect=OSError("offline")), RequestException=OSError)
        with patch.dict(sys.modules, {"requests": transport}):
            with self.assertRaisesRegex(OSError, "offline"):
                MAS(config()).call_llm("question")
        self.assertEqual(transport.post.call_count, 3)

    def test_async_uses_auth_and_temperature(self):
        class Response:
            async def __aenter__(self):
                return self
            async def __aexit__(self, *args):
                return False
            def raise_for_status(self):
                pass
            async def json(self):
                return {"choices": [{"message": {"content": "ok"}}]}
        class Session(Response):
            post = Mock(return_value=Response())
        transport = SimpleNamespace(ClientSession=Session, ClientTimeout=lambda **kwargs: kwargs,
                                    ClientError=OSError)
        with patch.dict(sys.modules, {"aiohttp": transport}):
            self.assertEqual(asyncio.run(MAS(config()).call_llm_async("q", temperature=0)), "ok")
        kwargs = Session.post.call_args.kwargs
        self.assertEqual(kwargs["json"]["temperature"], 0)
        self.assertEqual(kwargs["headers"]["Authorization"], "Bearer test-only")


class InferenceTests(WorkspaceTest):
    def test_constructor_error_is_saved_and_retryable(self):
        args = inference.parse_args([])
        with patch("inference.create_method", side_effect=ValueError("bad setup")):
            success = inference.process_sample(args, {}, {"query": "q"}, self.path, threading.Lock())
        self.assertFalse(success)
        self.assertIn("bad setup", list(load_jsonl(self.path))[0]["error"])
        self.assertEqual(len(reserve_unprocessed_queries(self.path, [{"query": "q"}])), 1)

    def test_batch_cardinality_guard(self):
        with self.assertRaisesRegex(ValueError, "count mismatch"):
            inference.validate_outputs([{"query": "q"}], [])

    def test_batch_null_response_guard(self):
        with self.assertRaises(ValueError):
            inference.validate_outputs([{}], [{"response": None}])

    def test_dry_run_without_backend(self):
        save_jsonl([{"query": str(n)} for n in range(5)], self.path)
        buffer = io.StringIO()
        with patch("inference.get_method_class", side_effect=AssertionError("backend loaded")):
            with contextlib.redirect_stdout(buffer):
                self.assertEqual(inference.main(["--input_file", str(self.path), "--start", "2",
                                                 "--max-samples", "2", "--dry-run"]), 0)
        self.assertEqual(json.loads(buffer.getvalue())["pending_samples"], 2)

    def test_empty_input_does_not_load_config(self):
        save_jsonl([], self.path)
        with patch("inference.load_model_api_config", side_effect=AssertionError("config loaded")):
            self.assertEqual(inference.main(["--input_file", str(self.path)]), 0)

    def test_short_constructor_and_modal_last_attempt(self):
        save_jsonl([{"query": "q"}], self.path)
        output = self.directory / "result.jsonl"
        class FakeMethod:
            attempts = 0
            def __init__(self, general_config, method_config_name=None):
                pass
            async def inference_vllm_batch(self, samples, dataset_name):
                FakeMethod.attempts += 1
                if FakeMethod.attempts < 3:
                    raise RuntimeError("temporary")
                return [{"response": "ok"}]
            def get_token_stats(self):
                return {}
        with patch("inference.get_method_class", return_value=FakeMethod):
            self.assertEqual(inference.main(["--input_file", str(self.path), "--output_path", str(output),
                                             "--use_modal_batch", "--retry_delay", "0"]), 0)
        self.assertEqual(FakeMethod.attempts, 3)
        self.assertEqual(list(load_jsonl(output))[0]["response"], "ok")

    def test_mismatched_batch_writes_nothing(self):
        save_jsonl([{"query": "q"}], self.path)
        output = self.directory / "result.jsonl"
        class FakeMethod:
            def __init__(self, general_config, method_config_name=None):
                pass
            def inference_batch(self, samples, dataset_name):
                return []
        with patch("inference.get_method_class", return_value=FakeMethod):
            with self.assertRaises(ValueError):
                inference.main(["--input_file", str(self.path), "--output_path", str(output), "--use_vllm"])
        self.assertFalse(output.exists())


class Tokenizer:
    def encode(self, text, **kwargs):
        return [ord(character) for character in text]
    def decode(self, ids):
        return "".join(chr(value) for value in ids)
    def apply_chat_template(self, messages, tokenize=True, add_generation_prompt=True):
        return [1] * 5 + self.encode(messages[0]["content"]) + [2] * 5


class LabelTests(WorkspaceTest):
    def test_failed_inference_is_not_labeled(self):
        save_jsonl([{"query": "q", "gt": "a", "response": "partial", "error": "failed"}], self.path)
        with self.assertRaisesRegex(ValueError, "successful nonempty response"):
            label.label_file_with_vllm(self.path, self.directory / "out.jsonl")

    def test_empty_label_input_needs_no_gpu(self):
        save_jsonl([], self.path)
        output = self.directory / "out.jsonl"
        label.label_file_with_vllm(self.path, output)
        self.assertEqual(list(load_jsonl(output)), [])

    def test_short_prompt_is_unchanged(self):
        self.assertEqual(label.truncate_for_vllm("short", Tokenizer(), 100), "short")

    def test_truncation_counts_template_and_marker(self):
        prompt = "a" * 200 + "TAIL"
        for budget in [40, 60, 100]:
            text = label.truncate_for_vllm(prompt, Tokenizer(), budget, 10)
            self.assertLessEqual(len(Tokenizer().apply_chat_template([{"content": text}])), budget)
            self.assertTrue(text.endswith("TAIL"))

    def test_zero_tail_does_not_duplicate_prompt(self):
        text = label.truncate_for_vllm("a" * 200, Tokenizer(), 60, 0)
        self.assertLessEqual(len(Tokenizer().apply_chat_template([{"content": text}])), 60)

    def test_too_small_budget_fails(self):
        with self.assertRaises(ValueError):
            label.truncate_for_vllm("a" * 200, Tokenizer(), 5)

    def test_sample_answers_removed_for_all_datasets(self):
        query = "Question\n## Sample Answers (Use them to guide the style of your answer)\nDO_NOT_KEEP\n--- End of Sample Answers ---"
        self.assertNotIn("DO_NOT_KEEP", label.build_label_prompt(query, "4", "4", "GSM8K"))

    def _backend(self, answer):
        class FakeLLM:
            kwargs = None
            prompts = None
            sampling = None
            def __init__(self, **kwargs):
                FakeLLM.kwargs = kwargs
            def get_tokenizer(self):
                return Tokenizer()
            def generate(self, prompts, sampling):
                FakeLLM.prompts = prompts
                FakeLLM.sampling = sampling
                return [SimpleNamespace(outputs=[SimpleNamespace(text=answer)]) for _ in prompts]
        fake = {"vllm": SimpleNamespace(LLM=FakeLLM, SamplingParams=lambda **kw: kw),
                "vllm.sampling_params": SimpleNamespace(GuidedDecodingParams=lambda **kw: kw),
                "tqdm": SimpleNamespace(tqdm=lambda values, **kw: values)}
        return FakeLLM, fake

    def test_label_pipeline_honors_token_and_gpu_options(self):
        save_jsonl([{"query": "1+3", "gt": "4", "response": "4"}], self.path)
        output = self.directory / "labeled.jsonl"
        backend, modules = self._backend("true")
        with patch.dict(sys.modules, modules):
            label.label_file_with_vllm(self.path, output, max_tokens=7, max_model_len=200,
                                      tensor_parallel_size=2, dataset_name="GSM8K")
        self.assertEqual(backend.kwargs["tensor_parallel_size"], 2)
        self.assertEqual(backend.sampling["max_tokens"], 7)
        self.assertLessEqual(len(backend.prompts[0]["prompt_token_ids"]) + 7, 200)
        self.assertEqual(list(load_jsonl(output))[0]["labels"], [True])

    def test_invalid_label_preserves_existing_file(self):
        save_jsonl([{"query": "q", "gt": "a", "response": "a"}], self.path)
        output = self.directory / "labeled.jsonl"
        output.write_text("old output", encoding="utf-8")
        _, modules = self._backend("maybe")
        with patch.dict(sys.modules, modules):
            with self.assertRaisesRegex(ValueError, "Invalid label"):
                label.label_file_with_vllm(self.path, output, tensor_parallel_size=1)
        self.assertEqual(output.read_text(encoding="utf-8"), "old output")


class CliTests(unittest.TestCase):
    def test_help_without_site_packages(self):
        for command in [["inference.py"], ["label.py"], ["evaluate.py"], ["-m", "eval.saved_results"]]:
            with self.subTest(command=command):
                result = subprocess.run([sys.executable, "-B", "-S", *command, "--help"],
                                        cwd=ROOT, capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn("usage:", result.stdout)

    def test_project_sources_compile(self):
        for path in ROOT.rglob("*.py"):
            with self.subTest(path=path.relative_to(ROOT)):
                compile(path.read_bytes(), str(path), "exec")


if __name__ == "__main__":
    unittest.main()
