import json
import os
from .jsonl import append_jsonl, load_jsonl, save_jsonl


def read_jsonl(f):
    return list(load_jsonl(f))


def write_jsonl(data, f):
    append_jsonl(f, data)


def load_model_api_config(model_api_config, model_name):
    with open(model_api_config, encoding="utf-8") as source:
        config = json.load(source)
    if model_name not in config:
        raise ValueError(f"Model {model_name!r} is not configured in {model_api_config}")
    for name, entry in config.items():
        models = entry.get("model_list", [])
        workers = entry.get("max_workers_per_model", 1)
        if not models or not isinstance(workers, int) or isinstance(workers, bool) or workers < 1:
            raise ValueError(f"Invalid model_list or max_workers_per_model for {name!r}")
        for model in models:
            if not model.get("model_name") or not model.get("model_url"):
                raise ValueError(f"Missing model_name/model_url for {name!r}")
            if model.get("api_key_env"):
                variable = model["api_key_env"]
                if variable not in os.environ:
                    raise ValueError(f"Required API key environment variable {variable!r} is unset")
                model["api_key"] = os.environ[variable]
        entry["max_workers"] = workers * len(models)
    return config


def write_to_jsonl(lock, file_name, data):
    append_jsonl(file_name, [data], lock)


def read_valid_jsonl(file_name):
    return list(load_jsonl(file_name, skip_invalid=True))


def reserve_unprocessed_queries(output_path, test_dataset):
    processed = set()
    if os.path.exists(output_path):
        for item in load_jsonl(output_path):
            if item.get("error"):
                continue
            if "eval_score" in item:
                complete = item["eval_score"] is not None
            else:
                complete = isinstance(item.get("response"), str) and bool(item["response"].strip())
            if complete and isinstance(item.get("query"), str):
                processed.add(item["query"])
    return [sample for sample in test_dataset if sample["query"] not in processed]
