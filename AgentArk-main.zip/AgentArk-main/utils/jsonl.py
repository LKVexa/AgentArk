"""Shared UTF-8 JSONL IO with contextual errors and atomic replacement."""
import json
import os
import tempfile
import warnings
from contextlib import nullcontext
from pathlib import Path


def load_jsonl(path, *, skip_invalid=False):
    with open(path, encoding="utf-8-sig") as source:
        for number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
                if not isinstance(value, dict):
                    raise ValueError("expected a JSON object")
            except (ValueError, TypeError) as error:
                message = f"{path}:{number}: invalid JSONL record ({error})"
                if not skip_invalid:
                    raise ValueError(message) from error
                warnings.warn(message, RuntimeWarning)
                continue
            yield value


def append_jsonl(path, rows, lock=None):
    payload = "".join(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n" for row in rows)
    if not payload:
        return
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with lock if lock is not None else nullcontext():
        with target.open("a+b") as destination:
            destination.seek(0, os.SEEK_END)
            length = destination.tell()
            if length:
                destination.seek(-1, os.SEEK_END)
                if destination.read(1) not in (b"\n", b"\r"):
                    position, tail = length, b""
                    while position:
                        size = min(position, 4096)
                        position -= size
                        destination.seek(position)
                        tail = destination.read(size) + tail
                        if b"\n" in tail:
                            break
                    try:
                        last = json.loads(tail.rsplit(b"\n", 1)[-1])
                        if not isinstance(last, dict):
                            raise ValueError("expected a JSON object")
                    except ValueError as error:
                        raise ValueError(f"{path}: incomplete final JSONL row; repair before appending") from error
                    destination.seek(0, os.SEEK_END)
                    destination.write(b"\n")
            destination.seek(0, os.SEEK_END)
            destination.write(payload.encode("utf-8"))
            destination.flush()


def save_jsonl(rows, path):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n",
                                         dir=target.parent, delete=False) as output:
            temporary = Path(output.name)
            for row in rows:
                output.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, target)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
