"""Finite scalar comparison, not symbolic mathematics grading.

Brace scan adapted from Microsoft ToRA src/utils/parser.py::extract_answer,
commit 213c1c995038c73fab10343814df7a42f990f026 (MIT).
See THIRD-PARTY-NOTICES.md for the license and adaptations.
"""
import re
from fractions import Fraction


def extract_boxed_answer(text):
    if not isinstance(text, str):
        return ""
    matches = list(re.finditer(r"\\(?:boxed|fbox)\s*\{", text))
    if not matches:
        return ""
    depth, answer = 1, []
    for character in text[matches[-1].end():]:
        if character == "{":
            depth += 1
        elif character == "}":
            depth -= 1
            if depth == 0:
                return "".join(answer).strip()
        answer.append(character)
    return ""


def extract_final_answer(text):
    text = str(text).strip()
    if re.search(r"\\(?:boxed|fbox)\b", text):
        return extract_boxed_answer(text)
    if "####" in text:
        return text.rsplit("####", 1)[1].strip()
    match = re.search(r"(?:final answer|the answer is)\s*:?\s*(.+)", text, re.I)
    return match.group(1).strip().rstrip(".") if match else text


def normalize_answer(value):
    if value is None:
        return ""
    value = extract_final_answer(value).replace("−", "-").strip().strip("$")
    value = value.replace(r"\left", "").replace(r"\right", "").replace(r"\,", "")
    value = value.replace(",", "").replace(r"\%", "%")
    return re.sub(r"\s+", "", value)


def _number(value):
    percent = value.endswith("%")
    if percent:
        value = value[:-1]
    fraction = re.fullmatch(r"([+-]?)\\(?:dfrac|tfrac|frac)\{([+-]?\d+)\}\{([+-]?\d+)\}", value)
    if fraction:
        number = Fraction(int(fraction[2]), int(fraction[3]))
        if fraction[1] == "-":
            number = -number
    elif re.fullmatch(r"[+-]?\d+/[+-]?\d+", value):
        numerator, denominator = value.split("/")
        number = Fraction(int(numerator), int(denominator))
    elif re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", value):
        if "e" in value.lower() and abs(int(value.lower().split("e")[1])) > 1000:
            raise ValueError("exponent is too large")
        number = Fraction(value)
    else:
        raise ValueError("not a supported scalar")
    return number / 100 if percent else number


def compare_answers(prediction, ground_truth):
    prediction, ground_truth = normalize_answer(prediction), normalize_answer(ground_truth)
    if not prediction or not ground_truth:
        return False
    try:
        return abs(_number(prediction) - _number(ground_truth)) < Fraction(1, 1_000_000)
    except (ValueError, ZeroDivisionError, OverflowError):
        return False
