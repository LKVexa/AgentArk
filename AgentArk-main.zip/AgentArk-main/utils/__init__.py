from .utils import (
    load_model_api_config, write_to_jsonl, reserve_unprocessed_queries,
    read_valid_jsonl, read_jsonl, write_jsonl,
)
from .jsonl import load_jsonl, save_jsonl


def lower_keys(example):
    return {key.lower(): value for key, value in example.items()}
