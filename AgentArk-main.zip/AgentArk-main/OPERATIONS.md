# Local Chop Shop revision

This revision repairs repository integration and supplies offline regression checks.
It does not establish new model benchmark results or validate distributed training.

## Local data and API setup

Inference accepts a JSON array or JSONL objects with a nonempty string `query`.
Keep a `gt` field for labeling and evaluation; other metadata is preserved.
Real datasets and model checkpoints are not included. Run commands from this
repository root. The included examples are small synthetic checks.

For API inference, install `requirements-api.txt`, copy
`model_api_configs/model_api_config.example.json` to
`model_api_configs/model_api_config.json`, and edit the model names and full
completion endpoint. Set the named environment variable for the key. You can omit
`api_key_env` and set `api_key` to an empty string for a local server that requires
no authentication. The configuration is ignored by Git.

```bash
python inference.py --input_file examples/input.jsonl --method_name vanilla --model_name local-model --output_path results/demo.jsonl
```

An API key is sent as a bearer header and is not printed by the CLI. The base client
supports message lists, system prompts, explicit zero temperature, timeouts and
at most five transport attempts by default. Subclasses with their own clients
(for example CAMEL) retain their own behavior.

## Resume and output rules

Inference slices the original input with `--start` then `--max-samples`, then
filters successfully completed queries. Failed/empty responses are retried. Existing
rows remain; resumed success adds a new row. Deduplication is by exact query text,
as in the original workflow. Use separate output files for different datasets,
configurations or model versions.

Malformed JSONL reports a path and line number. An interrupted, partial final row
must be repaired or removed after preserving a backup; it is never silently skipped
by resume. A complete final row without a newline is handled automatically.
Thread-safe appends require the supplied shared lock; separate processes must
use separate output files.

Batch outputs are checked for count and valid responses before that batch is
written. Earlier successful batches remain if a later batch fails. Labeling writes
its complete output atomically. Invalid labels and output-count mismatches raise
errors instead of turning uncertain labels into training negatives.

## Evaluation and model limits

`python -m eval.saved_results --input_file <file> --metric numeric` needs only
Python. Numeric grading accepts finite signed decimals, fractions, scientific
notation and percentages with absolute tolerance less than 0.000001. It rejects
symbolic expressions, empty values and nonfinite values. It extracts the last
explicit boxed answer, GSM8K #### answer, or final-answer marker; it does not
execute response text. `exact` ignores case and repeated whitespace; `token-f1`
uses token overlap after lowercasing and removal of punctuation and articles.
These metrics are not substitutes for the paper's benchmark protocol.

Each input row counts toward the denominator; error/missing-response rows score
zero. Missing ground truth is an input error. Use `--output report.jsonl` to save
a one-record summary. GPU generation and symbolic evaluation live in the original
`eval.math_eval`, `eval.short_answer_eval` and `eval.medmcqa_eval` modules.

The root `evaluate.py` is a legacy xverify client whose external `evaluations`
package was absent from the original ZIP. It now explains that dependency and
protects arbitrary input filenames from overwrite, but xverify itself is not
reimplemented here.

The original GPU dependency pins are retained. Their compatibility with every
advertised model family is unverified; in particular the original stack and model
list do not establish a tested combination. Linux/CUDA, model weights, datasets,
Modal service and distributed training were not exercised in this overhaul.
Method-specific assumptions (including multiple-choice prompting in CoT and
self-consistency) remain. Select an appropriate method/configuration for your data.

## Verification

```bash
python -m unittest discover -s tests -v
python inference.py --input_file examples/input.jsonl --dry-run
python -m eval.saved_results --input_file examples/predictions.jsonl --metric numeric
```

The tests use explicit fake model and HTTP transports; they make no network calls.
CI is provided for Windows/Linux and Python 3.10/3.12, but a local run does not
claim those remote jobs have executed. Existing vendored code emits some Python
3.13 invalid-escape SyntaxWarnings; source compilation succeeds.
