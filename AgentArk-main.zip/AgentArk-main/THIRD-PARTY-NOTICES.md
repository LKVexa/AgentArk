# Third-party notices

The repository's original Apache-2.0 LICENSE and all existing embedded licenses
are retained. This file records the part newly adapted during the local Chop Shop
overhaul; it does not claim to replace the notices in pre-existing third-party code.
The existing latex2sympy license remains at `eval/latex2sympy/LICENSE.txt`.

## Microsoft ToRA — MIT

Source: https://github.com/microsoft/ToRA

Pinned revision: `213c1c995038c73fab10343814df7a42f990f026`.
Source part: `src/utils/parser.py::extract_answer`, nested-brace extraction branch.
Source file SHA-256:
`ac4e3323044acd46a07a073e4903b137ea702ee048b07d64e99cff7b317f4b3f`.
Original LICENSE SHA-256:
`c2cfccb812fe482101a8f04597dfc5a9991a6b2748266c47ac91b6a5aae15383`.

Adapted into `utils/numeric.py::extract_boxed_answer`: explicit boxed/fbox command
matching, last-command selection, preservation of nested content, and rejection
of unbalanced braces. The finite-scalar comparison and shared callers are local
integration work. No ToRA datasets, model weights or execution engine are copied.
An unchanged donor license is also stored at `LICENSES/ToRA-MIT.txt`.

MIT License

Copyright (c) Microsoft Corporation.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE
